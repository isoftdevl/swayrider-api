

<?php $__env->startSection('content'); ?>
<h2>Hello <?php echo e($name); ?>,</h2>
<p>Thank you for registering with SwiftRider. To complete your registration and verify your email address, please use the One-Time Password (OTP) below:</p>

<div style="text-align: center; margin: 30px 0;">
    <span style="font-size: 32px; font-weight: bold; letter-spacing: 5px; color: #10b981; background-color: #ecfdf5; padding: 10px 20px; border-radius: 8px;"><?php echo e($code); ?></span>
</div>

<p>This code will expire in 15 minutes.</p>

<p>If you did not create an account with SwiftRider, please ignore this email.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ELEOJO\Downloads\SwiftRider\swiftrider-api\resources\views/emails/riders/verification.blade.php ENDPATH**/ ?>