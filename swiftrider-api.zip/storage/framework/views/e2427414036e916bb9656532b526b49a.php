

<?php $__env->startSection('content'); ?>
<h2>Congratulations <?php echo e($name); ?>!</h2>
<p>We are happy to inform you that your KYC verification was successful.</p>

<p>Your account has been fully activated, and you can now start accepting delivery requests and earning money with SwiftRider.</p>

<div style="text-align: center; margin: 30px 0;">
    <a href="#" class="button">Go to Dashboard</a>
</div>

<p>Happy Riding!</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ELEOJO\Downloads\SwiftRider\swiftrider-api\resources\views/emails/riders/kyc_approved.blade.php ENDPATH**/ ?>