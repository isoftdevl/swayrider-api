@extends('emails.layouts.main')

@section('content')
<h2 style="color: #ef4444;">New Login Detected</h2>
<p>Hello {{ $data['name'] }},</p>
<p>We noticed a new sign-in to your SwiftRider account from a new device.</p>

<div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
    <p style="margin: 5px 0;"><strong>Device:</strong> {{ $data['device_name'] }}</p>
    <p style="margin: 5px 0;"><strong>IP Address:</strong> {{ $data['ip_address'] }}</p>
    <p style="margin: 5px 0;"><strong>Time:</strong> {{ $data['time'] }}</p>
</div>

<p>If this was you, you can safely ignore this email.</p>

<p><strong>If you did not authorize this login, please change your password immediately and contact support.</strong></p>

<a href="mailto:support@swiftrider.com" class="button" style="background-color: #ef4444;">Contact Support</a>
@endsection
