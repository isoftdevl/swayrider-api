<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SwiftRider</title>
    <style>
        body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; margin-top: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .header { background-color: #10b981; padding: 20px; text-align: center; }
        .header h1 { color: #ffffff; margin: 0; font-size: 24px; }
        .content { padding: 30px; color: #333333; line-height: 1.6; }
        .footer { background-color: #f9fafb; padding: 20px; text-align: center; font-size: 12px; color: #6b7280; border-top: 1px solid #e5e7eb; }
        .button { display: inline-block; background-color: #10b981; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold; margin-top: 20px; }
        .social-links { margin-top: 10px; }
        .social-links a { color: #10b981; text-decoration: none; margin: 0 5px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header"> 
            <h1>SwiftRider</h1>
        </div>
        <div class="content">
            @yield('content')
            
            <p>Best regards,<br>The SwiftRider Team</p>
        </div>
        <div class="footer">
            <div class="social-links">
                <a href="https://x.com/SwiftRiderNG">Twitter</a> | <a href="https://web.facebook.com/SwiftRiderNG">Facebook</a> | <a href="https://instagram.com/SwiftRiderNG">Instagram</a>
            </div>
            <p>&copy; {{ date('Y') }} SwiftRider. All rights reserved.</p>
            <p>Need help? Contact us at <a href="mailto:support@swiftrider.com" style="color: #10b981;">support@swiftrider.com</a></p>
        </div>
    </div>
</body>
</html>
