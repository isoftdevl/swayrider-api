<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;
use Illuminate\Auth\AuthenticationException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Nwidart\Modules\Facades\Module;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     *
     * @return void
     */
    public function register()
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }

     /**
     * Convert an authentication exception into an unauthenticated response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Illuminate\Auth\AuthenticationException  $exception
     * @return \Illuminate\Http\Response
     */
    protected function unauthenticated($request, AuthenticationException $exception)
    {
        if ($request->expectsJson() || $request->is('api*')) {
            return response()->json(['error' => 'unauthenticated', 'message' => __('auth.unauthenticated')], 401);
        }

        if( Module::has('Frontend') && Module::isEnabled('Frontend') ) {
            return redirect()->guest(route('frontend.signin'));
        }
        return redirect()->guest(route('login'));
    }

    public function render($request, Throwable $exception)
    {
        if ($exception instanceof NotFoundHttpException || $exception instanceof ModelNotFoundException) {
            // Return JSON for API requests
            if ($request->expectsJson() || $request->is('api*')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Route not found',
                    'error' => 'not_found'
                ], 404);
            }

            if (Module::has('Frontend') && Module::isEnabled('Frontend')) {
                return redirect()->route('error.404');
            }

            // For web routes, return a simple 404 response
            return response()->json(['message' => 'Not Found'], 404);
        }
        
        return parent::render($request, $exception);
    }
}
