<?php

namespace App\Http\Controllers\Api\Company;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\CompanyInvitation;
use App\Models\Rider;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class CompanyController extends Controller
{
    public function dashboard(Request $request)
    {
        $company = $request->user();
        
        return response()->json([
            'success' => true,
            'data' => [
                'total_riders' => $company->riders()->count(),
                'active_riders' => $company->riders()->where('status', 'active')->count(),
                'wallet_balance' => $company->wallet ? $company->wallet->balance : 0,
                'total_earnings' => $company->wallet ? $company->wallet->total_credited : 0,
            ]
        ]);
    }

    public function inviteRider(Request $request)
    {
        $request->validate(['email' => 'required|email']);
        
        $company = $request->user();
        $token = Str::random(32);

        $invitation = CompanyInvitation::create([
            'company_id' => $company->id,
            'email' => $request->email,
            'token' => $token,
            'expires_at' => now()->addDays(7)
        ]);

        // In production: Mail::to($request->email)->send(new CompanyInviteMail($invitation));

        return response()->json([
            'success' => true,
            'message' => 'Invitation sent',
            'token' => $token 
        ]);
    }

    public function listRiders(Request $request)
    {
        return response()->json([
            'success' => true,
            'data' => $request->user()->riders()->paginate(20)
        ]);
    }

    public function getRiderChatMessages(Request $request, $id)
    {
        $company = $request->user();
        
        // Ensure the delivery belongs to one of the company's riders
        $delivery = Delivery::where('id', $id)
            ->whereHas('rider', function($q) use ($company) {
                $q->where('company_id', $company->id);
            })->firstOrFail();

        $chat = $delivery->chat;

        if (!$chat) {
            return response()->json(['data' => []]);
        }

        return response()->json([
            'success' => true,
            'data' => $chat->messages()->orderBy('created_at', 'asc')->get()
        ]);
    }
}
