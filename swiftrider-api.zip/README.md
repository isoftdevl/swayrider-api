# SwiftRider API

Complete RESTful API for the SwiftRider bike delivery platform.

## Technology Stack
- **Backend**: PHP 8.2+ with Laravel 11
- **Database**: MySQL 8.0
- **Authentication**: Laravel Sanctum
- **Payment**: Paystack
- **Maps**: Google Maps API
- **Real-time**: Pusher

## Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <url>
   cd swiftrider-api
   ```

2. **Install Dependencies**
   ```bash
   composer install
   ```

3. **Environment Setup**
   - Copy `.env.example` to `.env`
   - Set database credentials (`DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`)
   - Set Paystack Keys (`PAYSTACK_PUBLIC_KEY`, `PAYSTACK_SECRET_KEY`)
   - Set Google Maps Key (`GOOGLE_MAPS_API_KEY`)

4. **Generate Key**
   ```bash
   php artisan key:generate
   ```

5. **Run Migrations & Seeders**
   ```bash
   php artisan migrate --seed
   ```
   *This will create the admin user: admin@swiftrider.com / password*

6. **Serve**
   ```bash
   php artisan serve
   ```

## API Documentation

### Authentication
- `POST /api/user/register`
- `POST /api/user/login`
- `POST /api/rider/register`
- `POST /api/rider/login`
- `POST /api/admin/login`

### Delivery
- `POST /api/estimate-price` (Get price estimate)
- `POST /api/user/deliveries` (Request delivery)

### Rider KYC
- `POST /api/rider/kyc` (Submit KYC)

### Wallet
- `POST /api/user/wallet/fund` (Fund wallet via Paystack)

## Architecture
- **Controllers**: Located in `app/Http/Controllers/Api`
- **Services**: Business logic in `app/Services` (Pricing, Wallet, Payment)
- **Models**: Eloquent models in `app/Models` with relationships defined.
